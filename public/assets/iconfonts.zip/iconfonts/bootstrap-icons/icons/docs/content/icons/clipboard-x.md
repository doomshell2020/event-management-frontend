---
title: Clipboard x
categories:
  - Real world
tags:
  - copy
  - paste
---
