---
title: Badge 4k
categories:
  - Badges
tags:
  - 4k
  - display
  - resolution
  - retina
---
