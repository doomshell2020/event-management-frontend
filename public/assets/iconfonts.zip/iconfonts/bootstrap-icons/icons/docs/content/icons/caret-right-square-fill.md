---
title: Caret right square fill
layout: icon
categories:
  - Carets
tags:
  - caret
  - arrow
  - triangle
---
